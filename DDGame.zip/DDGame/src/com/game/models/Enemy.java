/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.game.models;
/**
 * This class depicts the enemy class. This class is extended from the GameCharacter
 * class. This class is intentionally made empty, so as to add attributes that might
 * be required for the next build..
 * @author Kaushik
 */
public class Enemy extends GameCharacter{
   public Enemy(){
    
    }
            
}
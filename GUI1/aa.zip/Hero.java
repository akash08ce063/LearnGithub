/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication53;

import java.util.ArrayList;

/**
 *
 * @author ak_pat
 */
public class Hero {
    
    private int currentWeponId;
    private int currentbeltsId;
    private int currentringId;
    private int helmetType;
    private int potion;

  

    
}
//armor/weapon/belt/boots/rings/helmet
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication53;

import java.util.ArrayList;

/**
 *
 * @author ak_pat
 */
public class Inventory {
    private ArrayList wepons;
    private ArrayList belts;
    private ArrayList rings;
    private ArrayList helmets;
   

  

    public ArrayList getHelmets() {
        return helmets;
    }

    public void addHelmet(int helmet) {
        this.helmets.add( helmet);
    }

    public void addWeapon(int WeaponType){
        this.wepons.add(WeaponType);
    }
    
    public ArrayList getWeapons(){
        return this.wepons;
    }
    
     public void addbelts(int WeaponType){
        this.belts.add(WeaponType);
    }
     
    public ArrayList getbelts(){
        return this.belts;
    }
    
     public void addrings(int WeaponType){
        this.rings.add(WeaponType);
    }
     
    public ArrayList getrings(){
        return this.rings;
    }
    
    
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication53;

import java.util.ArrayList;

/**
 *
 * @author ak_pat
 */
public class Enemy {
    private int helmetType;
    private int armorType;
    private ArrayList wepons;

    public int getHelmetType() {
        return helmetType;
    }

    public void setHelmetType(int helmetType) {
        this.helmetType = helmetType;
    }

    public int getArmorType() {
        return armorType;
    }

    public void setArmorType(int armorType) {
        this.armorType = armorType;
    }
    public void addWeapon(int WeaponType){
        this.wepons.add(WeaponType);
    }
    
    public ArrayList getWeapons(){
        return this.wepons;
    }
    
}
